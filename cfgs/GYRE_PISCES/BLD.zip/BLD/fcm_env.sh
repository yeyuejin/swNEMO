#!/bin/sh
PATH=/home/export/base/systest/swyyz/online/yeyuejin/full-nemo4/release-4.0.2.SP.master/cfgs/GYRE_PISCES/BLD/bin:$PATH
export PATH
